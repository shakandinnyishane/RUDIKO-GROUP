RUDIKO GROUP — STATIC WEBSITE
==============================

Files:
- index.html — website homepage
- RUDIKO GROUP COMPANY PROFILE 2026.pdf — company profile linked from the site
- assets/favicon.svg — website favicon

DEPLOY TO NETLIFY:
1. Go to https://app.netlify.com/
2. Sign in or create an account.
3. Choose Add new project / Deploy manually.
4. Upload this entire folder (or the ZIP contents) with index.html at the top level.
5. Netlify will provide a public *.netlify.app address.
6. You can connect a custom domain later from Domain settings.

DEPLOY TO GITHUB PAGES:
1. Create a GitHub repository.
2. Upload index.html, the PDF, and the assets folder.
3. In Settings > Pages, enable deployment from the main branch.
4. GitHub Pages will provide a public URL.

IMPORTANT:
Keep index.html, the PDF, and the assets folder in the same relative structure.
